chrome.runtime.onInstalled.addListener(() => {
  console.log("Password Reminder extension installed.");
});
